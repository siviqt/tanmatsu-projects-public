# TanRadio

TanRadio is an Internet radio application for the Tanmatsu platform.

On every launch, an 800 × 480 welcome screen explains Wi-Fi setup and the
SD-card station catalog. Press **Space** to close it and start TanRadio.
Wi-Fi, audio, and the station catalog initialize only after Space is pressed.
After Space, the UI opens immediately with a “Starting radio...” view while
Wi-Fi transport and SD-card setup run in the background. Volume, illumination
and confirmed exit remain usable. The station screen appears when setup
finishes; saved-network attempts continue in the background. An early Play
request waits for Wi-Fi; search asks you to retry after Wi-Fi connects.
The radio is reset on entry to discard any previous launcher's SDIO state;
this initialization runs in the background.

The Midnight theme uses a navy background, slate panels, cyan selection outlines,
Saira Condensed headings and Saira Regular body text. Status and help labels are
at least 18 pixels, with larger station names and search results.

Press **F1**, release it, then press **F1 again** to exit. **Esc** or **F2** cancels
and restores the previous screen without changing playback or search text.
Holding F1 cannot confirm. The prompt works on the welcome screen, player,
search and removal dialog, and wakes illumination if needed. Volume remains
available while confirming; the prompt stays illuminated. On confirmation, a
goodbye splash appears for at least one second before audio cleanup and return
to the launcher. Welcome-screen exit does not start Wi-Fi or audio.

## Find and add stations

Press **F2** to open **Add station**. Type a station name and press **Enter**
to search Radio Browser. Press **Tab** to switch between station name and
country search (switching clears the query). In country mode, enter a country
name such as `Bulgaria` or a two-letter code such as `BG` (case-insensitive).
Press **Enter**, then use **Up/Down** to select one of up to 20 results,
then **F4** to play a preview or **F5** to save it. **F2** or **Esc** returns to the
station list. Typing or closing the dialog cancels an outstanding search;
preview playback continues when the dialog closes. Saved results are marked
**Saved**; their Save action is disabled. Moving to another result clears the
previous confirmation message. F3 stop, volume, and illumination controls
remain available while searching.

Opening and closing search only changes the UI. Rendering runs on the UI task,
and opening the dialog does not stop, mute, or replace the current station.

## Keyboard controls

| Key | Station list | Station search |
| --- | --- | --- |
| F1 | Ask to exit; F1 again confirms | Ask to exit; F1 again confirms |
| F2 | Find stations | Back to station list |
| F3 | Stop | Stop |
| F4 | Play / Mute / Unmute | Play / Mute / Unmute |
| F5 | Play next saved station | Save selected result |
| F6 / power button | Toggle illumination | Toggle illumination |
| Up / Down | Move highlight | Move highlight |
| Enter | Play highlighted station; never mute | Search by name |
| Esc | Highlight current station | Back to station list |
| Backspace | Remove highlighted saved station (confirmation) | Delete previous character |

F4 shows **Play** when stopped or when another station is highlighted. For
the active station it shows **Mute** or **Unmute**, including while buffering;
it does not reconnect the stream. UUID or stream URL identifies a station,
so saving a preview or finding it again preserves its active playback state.
An unsaved preview remains selected as a temporary **Preview** row when you
leave search. It disappears when you play another station or save the preview.

On the station list, Backspace opens a removal confirmation naming the
highlighted saved station. F4 removes it; F2 cancels. Enter does not confirm.
Removing the active station keeps playback running and selects it as a
**Preview**. Preview rows cannot be removed; save the station again from search
if needed. A failed removal leaves the saved list intact and offers F4 to
retry or F2 to cancel.

Arrows, Backspace and volume repeat after 500 ms, then every 100 ms. Function
keys, Enter and Esc act once per press. A screen change cancels a previous
held-key repeat. Printable text and navigation events are handled separately
so Space and Backspace are not applied twice. Only the six physical function
keys are used; no synthesized Fn+number shortcuts are required.

## Station catalog

Search currently accepts direct, non-HLS MP3 streams. Refine the name or country to find
more specific results. Radio Browser's compatibility and availability data
can be stale, so individual stations may still fail to play. Directory errors
do not replace the saved station list or interrupt an existing stream.

An SD card is required. TanRadio includes no bundled stations: a new catalog
starts empty. Press F2 to find stations and F5 to save them. Existing SD-card
catalogs remain unchanged. Saved stations are appended to
`/tanradio/stations.txt`, preserving existing records and comments. Repeated
saves of the same UUID or stream URL do not add duplicates. The catalog holds
up to 128 stations and 64 KiB; names and URLs are limited to 96 and 512 bytes.
Radio Browser UUIDs are stored in `#RADIOBROWSERUUID:` comments immediately
before their station records, keeping the existing text format readable.
Temporary and backup files protect the catalog during saves; a backup is
recovered on startup if a save was interrupted between renames.

Radio Browser requests use verified HTTPS and discover mirrors through its
DNS SRV record, with retries on another mirror. Search runs in a background
task. User-initiated playback of directory stations sends a best-effort click
notification, including when a saved station is played later. Playback does
not wait for this notification. See the [Radio Browser API](https://api.radio-browser.info/).

Search reports connection failures separately from invalid or oversized
responses. A directory connection failure can also indicate a remote service
or network outage; saved stations and playback remain available. Directory
connections retain TLS certificate verification and use a five-second socket
timeout. When discovery returns only one server, a search connection failure
gets one automatic retry after 200 ms. Cancellation still stops the retry;
playback click notifications are not retried. Diagnostics identify the mirror
and TLS error without logging queries.

## Production build

Install ESP-IDF **v6.0.2**, then run `make build`. Set `IDF_PATH` and
`IDF_TOOLS_PATH` if your SDK is installed outside the default locations shown
by `make print-sdk`. The firmware is built as `build/tanmatsu/application.bin`.

The latest packaged application is [releases/TanRadio.bin](releases/TanRadio.bin).
Run `make release` to rebuild it and update its SHA-256 checksum. Verify it with
`cd releases && sha256sum -c TanRadio.bin.sha256`. This is the application image
for installation through the Tanmatsu launcher/AppFS tooling; it is not a
merged full-flash image.

The production application uses the tested ES8156 driver and matching badge
BSP in `local-components/`. The BSP configures left-justified 16-bit stereo
output and serializes codec transactions on the shared I2C bus. Startup volume
is 50%, with 1% adjustment steps and the driver's percentage-to-dB mapping.
Keep both local components together; the registry BSP/driver pair is not an
equivalent replacement. See [local-components/README.md](local-components/README.md).

`dependencies.lock` pins the other components. ESP-IDF downloads them into
`managed_components/` when needed; registry access is required unless they are
already cached. Generated dependencies and build outputs are not source files.

The display uses RGB565, native framebuffer switching with safe page retirement,
and a 256 KiB L2 cache with 128-byte lines. The current device test completed
15 station starts without an observed blue flash. See [ARCHITECTURE.md](ARCHITECTURE.md)
for ownership and timing details and [CHANGELOG.md](CHANGELOG.md) for validation.

Run `make test` after a build for all ten regression checks. Host checks require
Python 3 and a C compiler with pthreads and sanitizer support; the UI stack check
also uses the ESP32-P4 build output. See [tools/README.md](tools/README.md).
Use `make clean` to remove build outputs, or `make fullclean` to also
remove downloaded dependencies. Both preserve the production configuration
in `sdkconfig_tanmatsu`, the defaults in `sdkconfigs/`, and the packaged release.

## Install through BadgeLink

Return to the launcher and enable BadgeLink mode. Set `BADGELINK` to the installed
BadgeLink executable or script; it can also be a command available on `PATH`.

```sh
make install BADGELINK=/path/to/badgelink.sh
make run BADGELINK=/path/to/badgelink.sh
```

These targets upload/start the AppFS application named `tanradio`. They do not
flash the launcher or coprocessor. The Tanmatsu's main processor uses ttyACM0
when exposing its debug serial interface; ttyACM1 is the coprocessor. BadgeLink
can use its direct USB interface, so a serial device need not appear in that mode.

## Source sharing

Run `make source-export` to create `dist/TanRadio-source/`. Copy that folder to
the location of your new Git repository. It contains the current application
source, local components and their licenses, build configuration, pinned
dependencies, assets, documentation, tests, and the current binary/checksum.
It includes neither Git history nor generated build/download caches, machine
SDK paths, or component-publishing workflows. Export fails if the privacy
check detects private machine paths or credential material. Run
`python3 tools/check_privacy.py dist/TanRadio-source` to repeat that check.

The export includes `SOURCE_MANIFEST.sha256`. From the exported folder, run:

```sh
sha256sum -c SOURCE_MANIFEST.sha256
make build
make test
```

Install ESP-IDF v6.0.2 and set its paths as described above before building.
`make source-export SOURCE_EXPORT=/another/new/folder` selects another output
location. Export refuses to overwrite an existing folder, preserving any edits
or Git repository you have created there. `dist/` is ignored by the working
repository; the exported files are ready to add to your separate repository.
