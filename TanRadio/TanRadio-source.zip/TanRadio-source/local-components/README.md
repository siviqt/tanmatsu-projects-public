# Production audio components

These components were promoted from the tested TanRadio ES8156 build.
`main/idf_component.yml` explicitly overrides the registry dependencies with
these directories, including the BSP's transitive ES8156 dependency.

- `nicolaielectronics__es8156`: tested codec implementation with chip ID
  validation, single-register readbacks, register corrections, left-justified
  serial data configuration, and percentage volume accessors.
- `badgeteam__badge-bsp`: badge BSP 1.1.0 with the matching Tanmatsu audio
  changes: MSB/left-justified I2S slots, bus locking around codec initialization
  and volume access, and the driver's percentage volume API.
  The input source also corrects right-Shift modifier reporting and dormant
  repeat bookkeeping. TanRadio owns navigation/editing repeat; the BSP text
  repeat task remains disabled to prevent duplicate events.
  With two framebuffers, display submissions copy into the inactive native page
  and use ESP-IDF's page-flip path. Two refresh completions retire the old page
  before reuse, including after timeouts. External-buffer submissions otherwise
  select a DMA2D copy into the active page, defeating double buffering.

The application starts at the tested 50% volume. The driver's volume scale
spans -95.5 dB to +32 dB in 0.5 dB steps. Application mute and shutdown continue
to use the BSP audio interface; shutdown also disables the amplifier and I2S.

Keep the upstream MIT licenses and component manifests. The BSP retains its
upstream common code, stubs, and target structure to make future updates
reviewable. Do not edit generated copies in `managed_components/`.
