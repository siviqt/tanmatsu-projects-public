# Current TanRadio application

`TanRadio.bin` is the Tanmatsu ESP32-P4 AppFS application compiled with
ESP-IDF v6.0.2. It includes station-name and country search: open Find with F2,
press Tab to choose Name/Country, type a name or two-letter country code,
and press Enter. It also includes the Midnight UI, confirmed exit,
responsive startup, station saving/removal and native framebuffer switching.

This build passes the host regression checks and target stack checks.
The country-search update has not yet been tested on a device. Earlier playback
and display validation is recorded in CHANGELOG.md.

Install this application through the Tanmatsu launcher/BadgeLink tooling.
It is an application image, not a merged full-flash or coprocessor image.

Verify from this directory:

```sh
sha256sum -c TanRadio.bin.sha256
```

The included image has CRC32 `1d5c2cdb` and SHA-256:

```text
bb5d426c06c6b27b7a351e604fda3a5d4bd1bbb0dff087333f7ce473dbe9b797
```

Run `make release` from the source root to build a replacement and refresh the
sidecar. A rebuild may have different metadata/checksums. Distribute each binary
with its matching sidecar; retain only the latest production image here.
