#!/usr/bin/env python3
"""Compile the real audio module against a blocking host I2S mock.

Run with python3 tools/tests/test_audio_shutdown.py (requires cc and pthreads).
This checks lock independence and exit ordering; it does not emulate FreeRTOS.
"""
from pathlib import Path
import subprocess
import tempfile

ROOT = Path(__file__).resolve().parents[2]
STUBS = r'''
#pragma once
#include <assert.h>
#include <stdbool.h>
#include <stdint.h>
#include <stddef.h>
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <stdatomic.h>
#include <time.h>
typedef int esp_err_t;
#define ESP_OK 0
#define ESP_ERR_INVALID_STATE 1
#define ESP_ERR_INVALID_ARG 2
#define ESP_ERR_TIMEOUT 3
#define portMAX_DELAY UINT32_MAX
#define ESP_LOGE(tag, ...) ((void)(tag))
#define ESP_LOGW(tag, ...) ((void)(tag))
#define ESP_LOGI(tag, ...) ((void)(tag))
typedef pthread_mutex_t *SemaphoreHandle_t;
static SemaphoreHandle_t xSemaphoreCreateMutex(void) {
    SemaphoreHandle_t m = malloc(sizeof(*m));
    assert(m && pthread_mutex_init(m, NULL) == 0);
    return m;
}
static int xSemaphoreTake(SemaphoreHandle_t m, uint32_t timeout) {
    (void)timeout; assert(pthread_mutex_lock(m) == 0); return 1;
}
static int xSemaphoreGive(SemaphoreHandle_t m) {
    assert(pthread_mutex_unlock(m) == 0); return 1;
}
typedef void *i2s_chan_handle_t;
typedef struct { uint32_t total_dma_buf_size; } i2s_chan_info_t;
static atomic_bool writing, release_write, control_done, amp, force, disabled;
static atomic_int volume, writes;
static atomic_size_t silence_bytes;
static void pause_thread(void) {
    struct timespec duration = {0, 1000000}; nanosleep(&duration, NULL);
}
static void wait_flag(atomic_bool *flag) {
    for (int i = 0; i < 2000 && !atomic_load(flag); i++) pause_thread();
    assert(atomic_load(flag));
}
static esp_err_t bsp_audio_get_i2s_handle(i2s_chan_handle_t *h) { *h = (void *)1; return ESP_OK; }
static esp_err_t bsp_audio_set_volume(float v) { atomic_store(&volume, (int)v); return ESP_OK; }
static esp_err_t bsp_audio_set_amplifier(bool v) { atomic_store(&amp, v); return ESP_OK; }
static esp_err_t bsp_audio_set_amplifier_force(bool v) { atomic_store(&force, v); return ESP_OK; }
static esp_err_t i2s_channel_get_info(i2s_chan_handle_t h, i2s_chan_info_t *info) {
    assert(h); info->total_dma_buf_size = 5760; return ESP_OK;
}
static esp_err_t i2s_channel_write(i2s_chan_handle_t h, const void *data, size_t size,
                                  size_t *written, uint32_t timeout) {
    assert(h && timeout != portMAX_DELAY && !atomic_load(&disabled));
    if (atomic_fetch_add(&writes, 1) == 0) {
        atomic_store(&writing, true);
        wait_flag(&release_write);
    } else {
        assert(atomic_load(&volume) == 0 && !atomic_load(&amp) && !atomic_load(&force));
        const uint8_t *bytes = data;
        for (size_t i = 0; i < size; i++) assert(bytes[i] == 0);
        atomic_fetch_add(&silence_bytes, size);
    }
    *written = size;
    return ESP_OK;
}
static esp_err_t i2s_channel_disable(i2s_chan_handle_t h) {
    assert(h && atomic_load(&silence_bytes) == 11520);
    atomic_store(&disabled, true); return ESP_OK;
}
'''
TEST = r'''
#include "main/audio/audio.c"
static void *play(void *arg) {
    (void)arg; const uint8_t pcm[32] = {1};
    assert(audio_write_pcm(pcm, sizeof(pcm)) == ESP_OK); return NULL;
}
static void *control(void *arg) {
    (void)arg;
    assert(audio_volume_up() == ESP_OK);
    assert(audio_mute() == ESP_OK);
    assert(audio_unmute() == ESP_OK);
    atomic_store(&control_done, true); return NULL;
}
static void *shutdown_output(void *arg) { (void)arg; audio_shutdown(); return NULL; }
int main(void) {
    pthread_t playback, keys, shutdown;
    audio_init();
    assert(audio_get_volume() == 50);
    assert(audio_volume_up() == ESP_OK && audio_get_volume() == 51);
    assert(audio_volume_down() == ESP_OK && audio_get_volume() == 50);
    for (unsigned n = 50; n < 100; n++) {
        assert(audio_volume_up() == ESP_OK && audio_get_volume() == n + 1);
    }
    assert(audio_volume_up() == ESP_OK && audio_get_volume() == 100);
    for (unsigned n = 100; n > 0; n--) {
        assert(audio_volume_down() == ESP_OK && audio_get_volume() == n - 1);
    }
    assert(audio_volume_down() == ESP_OK && audio_get_volume() == 0);
    assert(audio_mute() == ESP_OK);
    assert(audio_volume_up() == ESP_OK && audio_get_volume() == 1);
    assert(atomic_load(&volume) == 0);
    assert(audio_unmute() == ESP_OK && atomic_load(&volume) == 1);
    for (unsigned n = 1; n < 50; n++) assert(audio_volume_up() == ESP_OK);
    assert(pthread_create(&playback, NULL, play, NULL) == 0);
    wait_flag(&writing);
    assert(pthread_create(&keys, NULL, control, NULL) == 0);
    /* Key controls must finish while the PCM write is still blocked. */
    wait_flag(&control_done);
    assert(!atomic_load(&release_write) && atomic_load(&volume) == 51);
    pthread_join(keys, NULL);
    assert(pthread_create(&shutdown, NULL, shutdown_output, NULL) == 0);
    wait_flag(&audio_shutdown_started);
    const uint8_t pcm[4] = {1};
    assert(audio_write_pcm(pcm, sizeof(pcm)) == ESP_ERR_INVALID_STATE);
    assert(atomic_load(&writes) == 1);
    atomic_store(&release_write, true);
    pthread_join(playback, NULL);
    pthread_join(shutdown, NULL);
    assert(atomic_load(&disabled));
    assert(audio_unmute() == ESP_ERR_INVALID_STATE);
    int before = atomic_load(&writes);
    audio_shutdown();
    assert(atomic_load(&writes) == before && atomic_load(&volume) == 0);
    puts("PASS: controls stay responsive during PCM writes; shutdown blocks new PCM/unmute, flushes silence, and can repeat");
}
'''
with tempfile.TemporaryDirectory(prefix="tanradio-audio-test-") as directory:
    tmp = Path(directory)
    (tmp / "stubs.h").write_text(STUBS)
    for name in ("esp_err.h", "esp_log.h", "freertos/FreeRTOS.h",
                 "freertos/semphr.h", "driver/i2s_std.h", "bsp/audio.h"):
        path = tmp / name
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text('#include "stubs.h"\n')
    (tmp / "test.c").write_text(TEST)
    binary = tmp / "test"
    subprocess.run(["cc", "-std=c11", "-Wall", "-Wextra", "-Wno-unused-parameter",
                    "-pthread", "-I", str(tmp), "-I", str(ROOT),
                    str(tmp / "test.c"), "-o", str(binary)], check=True)
    subprocess.run([str(binary)], check=True, timeout=10)
