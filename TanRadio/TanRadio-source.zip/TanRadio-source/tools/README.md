# TanRadio Development Tools

This directory contains helper scripts used during development.

These tools are not part of the firmware image. Their purpose is to automate repetitive development tasks, enforce project standards, and improve reproducibility.

After `make build`, run `make test` for all ten regression checks below,
including station removal and display scheduling. Run `make source-export` to
create a sharing snapshot through `export_source.py`. The exporter uses an
explicit source list, excludes generated/private directories, writes a SHA-256
manifest, and refuses to overwrite an existing destination. Before publishing the snapshot,
it checks for private machine paths, embedded private keys, and credential
assignments/tokens. Run `python3 tools/check_privacy.py` to check the working
source or pass an export directory to audit that snapshot. The check skips Git
history and generated build/dependency caches; public upstream credits and
certificate-authority contacts are retained. This is a heuristic check, so
review any newly added personal data before sharing.

Run `python3 tools/tests/test_audio_shutdown.py` to check audio control responsiveness
and shutdown ordering against a deliberately blocked PCM write. This host test
requires a C compiler (`cc`) and pthreads; it does not require a connected device.
It complements, but does not replace, on-device playback and exit checks.
It also checks 1% volume changes, saturation at 0/100%, and muted adjustment.

Run `python3 tools/tests/test_app_startup.py` to verify UI/input are active
before transport/catalog setup, atomic service publication, startup-task
failure handling and welcome exit. The exit test also covers shutdown while
background initialization is in progress.

Run `python3 tools/tests/test_network_startup.py` to verify transport/stack
initialization precedes scheduling saved-network attempts, a simulated slow
connection does not block the caller, and readiness/failure paths are safe.

After `make build` has fetched cJSON, run
`python3 tools/tests/test_radio_browser.py` for the real directory parsers and
SD catalog implementation. It uses temporary files, AddressSanitizer and
UndefinedBehaviorSanitizer, and injected rename/fsync failures to verify
compatibility filtering, DNS bounds, duplicate handling, persistence, limits,
and interrupted-save recovery. It requires `cc` with sanitizer support and
does not access the network or the device's SD card.

Run `python3 tools/tests/test_controls.py` to exercise the production control
decisions, preview selection, station identity, duplicate presses, key releases,
repeat timing and tick-counter rollover. It compiles against the actual BSP
input declarations and a mocked playback backend. It also checks saving an
active preview without restarting playback, and navigation with an empty catalog.

Run `python3 tools/tests/test_exit.py` to check the real F1 routing and welcome
event loop: two distinct presses, held-key rejection, cancel, display wake,
modal controls, startup exit without audio initialization, failed display retries
and the splash-before-shutdown ordering. It uses host mocks and sanitizers.

After `make build`, run `python3 tools/tests/test_ui_stack.py` to check the
ESP32-P4 compiler's actual stack frames and object-code render call sites.
Rendering must stay on the UI task (plus startup), with at most 2 KiB of
application render frames on its 8 KiB stack. This reserves space for graphics
and library calls and catches target stack exhaustion missed by host tests.

Run `python3 tools/tests/test_display_updates.py` to check redraw coalescing,
frame-rate limits, native page flips, two-frame retirement, timeout ownership,
partial updates and automatic retry delivery. These host checks do not
simulate PSRAM arbitration or establish that rare hardware underruns are gone.
