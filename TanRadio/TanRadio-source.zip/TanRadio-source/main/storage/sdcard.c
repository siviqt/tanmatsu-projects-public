/*
 * TanRadio SD-card mount service.
 *
 * The pinout, power control, and ESP-Hosted workaround match the Tanmatsu
 * launcher. The card reader uses SDMMC slot 0 while ESP-Hosted Wi-Fi uses
 * slot 1.
 */
#include "storage/sdcard.h"

#include <stdio.h>

#include "driver/gpio.h"
#include "driver/sdmmc_host.h"
#include "esp_check.h"
#include "esp_heap_caps.h"
#include "esp_idf_version.h"
#include "esp_log.h"
#include "esp_vfs_fat.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "sd_pwr_ctrl.h"
#include "sd_pwr_ctrl_by_on_chip_ldo.h"
#include "sdmmc_cmd.h"

static const char *TAG = "tanradio.sd";

static sdmmc_card_t *card = NULL;
static sd_pwr_ctrl_handle_t power_handle = NULL;

#if defined(CONFIG_ESP_HOSTED_SDIO_HOST_INTERFACE) && \
    (ESP_IDF_VERSION >= ESP_IDF_VERSION_VAL(6, 0, 0))
#define TANRADIO_SD_HOSTED_WORKAROUND 1
#else
#define TANRADIO_SD_HOSTED_WORKAROUND 0
#endif

#if TANRADIO_SD_HOSTED_WORKAROUND
static esp_err_t sdmmc_host_init_noop(void)
{
    return ESP_OK;
}

static esp_err_t sdmmc_host_deinit_noop(void)
{
    return ESP_OK;
}
#endif

static esp_err_t sd_power_initialize(void)
{
    if (power_handle != NULL) {
        return ESP_OK;
    }

    const sd_pwr_ctrl_ldo_config_t config = {
        .ldo_chan_id = 4,
    };

    return sd_pwr_ctrl_new_on_chip_ldo(&config, &power_handle);
}

static esp_err_t sd_power_cycle(void)
{
    const uint64_t pins =
        BIT64(GPIO_NUM_39) | BIT64(GPIO_NUM_40) |
        BIT64(GPIO_NUM_41) | BIT64(GPIO_NUM_42) |
        BIT64(GPIO_NUM_43) | BIT64(GPIO_NUM_44);

    gpio_config_t pin_config = {
        .pin_bit_mask = pins,
        .mode = GPIO_MODE_OUTPUT_OD,
        .pull_up_en = GPIO_PULLUP_DISABLE,
        .pull_down_en = GPIO_PULLDOWN_DISABLE,
        .intr_type = GPIO_INTR_DISABLE,
    };

    ESP_RETURN_ON_ERROR(gpio_config(&pin_config), TAG,
                        "Unable to configure SD-card pins");

    for (gpio_num_t pin = GPIO_NUM_39; pin <= GPIO_NUM_44; pin++) {
        ESP_RETURN_ON_ERROR(gpio_set_level(pin, 0), TAG,
                            "Unable to pull SD-card pins low");
    }

    ESP_RETURN_ON_ERROR(sd_pwr_ctrl_set_io_voltage(power_handle, 0), TAG,
                        "Unable to power down SD card");
    vTaskDelay(pdMS_TO_TICKS(150));

    pin_config.mode = GPIO_MODE_INPUT;
    ESP_RETURN_ON_ERROR(gpio_config(&pin_config), TAG,
                        "Unable to release SD-card pins");
    ESP_RETURN_ON_ERROR(sd_pwr_ctrl_set_io_voltage(power_handle, 3300), TAG,
                        "Unable to power up SD card");
    vTaskDelay(pdMS_TO_TICKS(150));

    return ESP_OK;
}

esp_err_t tanradio_sd_mount(void)
{
    if (card != NULL) {
        return ESP_OK;
    }

    ESP_RETURN_ON_ERROR(sd_power_initialize(), TAG,
                        "Unable to acquire SD-card power control");
    ESP_RETURN_ON_ERROR(sd_power_cycle(), TAG,
                        "Unable to reset SD card");

    static uint8_t *dma_buffer = NULL;
    if (dma_buffer == NULL) {
        dma_buffer = heap_caps_malloc(
            512 * 4,
            MALLOC_CAP_DMA | MALLOC_CAP_INTERNAL);
        if (dma_buffer == NULL) {
            return ESP_ERR_NO_MEM;
        }
    }

    sdmmc_host_t host = SDMMC_HOST_DEFAULT();
    host.slot = SDMMC_HOST_SLOT_0;
    host.max_freq_khz = SDMMC_FREQ_HIGHSPEED;
    host.pwr_ctrl_handle = power_handle;
    host.dma_aligned_buffer = dma_buffer;

#if TANRADIO_SD_HOSTED_WORKAROUND
    host.init = sdmmc_host_init_noop;
    host.deinit = sdmmc_host_deinit_noop;
#endif

    sdmmc_slot_config_t slot = SDMMC_SLOT_CONFIG_DEFAULT();
    slot.clk = GPIO_NUM_43;
    slot.cmd = GPIO_NUM_44;
    slot.d0 = GPIO_NUM_39;
    slot.d1 = GPIO_NUM_40;
    slot.d2 = GPIO_NUM_41;
    slot.d3 = GPIO_NUM_42;
    slot.width = 4;

    const esp_vfs_fat_mount_config_t mount = {
        .format_if_mount_failed = false,
        .max_files = 4,
        .allocation_unit_size = 16 * 1024,
    };

    esp_err_t result = esp_vfs_fat_sdmmc_mount(
        TANRADIO_SD_MOUNT_POINT,
        &host,
        &slot,
        &mount,
        &card);
    if (result != ESP_OK) {
        ESP_LOGE(TAG, "Unable to mount SD card: %s", esp_err_to_name(result));
        return result;
    }

    ESP_LOGI(TAG, "SD card mounted at %s", TANRADIO_SD_MOUNT_POINT);
    sdmmc_card_print_info(stdout, card);
    return ESP_OK;
}
