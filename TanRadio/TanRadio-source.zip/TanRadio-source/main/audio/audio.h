/******************************************************************************
 *
 * Project : TanRadio
 * Module  : audio
 * File    : audio.h
 *
 * Purpose :
 *     Public interface for the audio module.
 *
 ******************************************************************************/

#ifndef TANRADIO_MAIN_AUDIO_AUDIO_H
#define TANRADIO_MAIN_AUDIO_AUDIO_H

#include <stddef.h>
#include <stdint.h>
#include "esp_err.h"

/**
 * @brief Initialize the audio subsystem.
 */
void audio_init(void);

/**
 * @brief Increase application-tracked audio volume by 1%, up to 100%.
 */
esp_err_t audio_volume_up(void);

/**
 * @brief Decrease application-tracked audio volume by 1%, down to 0%.
 */
esp_err_t audio_volume_down(void);

/**
 * @brief Get the application-tracked audio volume.
 *
 * @return Current volume percentage, 0-100.
 */
uint8_t audio_get_volume(void);

/**
 * @brief Write decoded PCM samples to the BSP-owned audio output.
 *
 * @param data PCM sample buffer.
 * @param size Number of PCM bytes to write.
 * @return ESP_OK on success, otherwise an ESP-IDF error.
 */
esp_err_t audio_write_pcm(const void *data, size_t size);

/**
 * @brief Mute the audio codec without changing the configured volume.
 */
esp_err_t audio_mute(void);

/**
 * @brief Restore the configured volume after a temporary mute.
 */
esp_err_t audio_unmute(void);

/**
 * @brief Permanently silence output before returning to the launcher.
 * Blocks subsequent PCM writes and volume changes until restart.
 */
void audio_shutdown(void);

#endif /* TANRADIO_MAIN_AUDIO_AUDIO_H */
