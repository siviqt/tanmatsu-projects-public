/******************************************************************************
 *
 * Project : TanRadio
 * Module  : audio
 * File    : audio.c
 *
 * Purpose :
 *     TanRadio audio subsystem.
 *
 ******************************************************************************/

#include <stdbool.h>
#include <stdatomic.h>

/* ESP-IDF */
#include "esp_log.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "driver/i2s_std.h"

/* Tanmatsu/BSP audio */
#include "bsp/audio.h"

/* Local header */
#include "audio.h"

static const char *TAG = "tanradio.audio";

/* BSP-owned I2S channel handle. */
static i2s_chan_handle_t i2s_handle = NULL;

/* TanRadio-owned volume state. */
static uint8_t audio_volume_percentage = 50;
static bool audio_muted = false;
/* PCM writes must not hold the control lock needed by key actions. */
static SemaphoreHandle_t audio_control_mutex = NULL;
static SemaphoreHandle_t audio_write_mutex = NULL;
static atomic_bool audio_shutdown_started = false;

/* Serialize codec changes with shutdown so a late unmute cannot undo it. */
static esp_err_t audio_set_output_volume(float percentage)
{
    if (audio_control_mutex == NULL) {
        return ESP_ERR_INVALID_STATE;
    }
    xSemaphoreTake(audio_control_mutex, portMAX_DELAY);
    esp_err_t res = audio_shutdown_started
                        ? ESP_ERR_INVALID_STATE
                        : bsp_audio_set_volume(percentage);
    xSemaphoreGive(audio_control_mutex);
    return res;
}

/******************************************************************************
 * Public Functions
 ******************************************************************************/

/**
 * @brief Initialize the audio subsystem.
 */
void audio_init(void)
{
    esp_err_t res;

    audio_control_mutex = xSemaphoreCreateMutex();
    audio_write_mutex = xSemaphoreCreateMutex();
    if (audio_control_mutex == NULL || audio_write_mutex == NULL) {
        ESP_LOGE(TAG, "Failed to allocate audio output mutex");
        return;
    }

    /*
     * The BSP has already initialized the codec and I2S hardware.
     * Obtain the BSP-owned I2S handle for future PCM playback.
     */
    res = bsp_audio_get_i2s_handle(&i2s_handle);
    if (res != ESP_OK) {
        ESP_LOGE(TAG, "Failed to obtain BSP audio I2S handle: %s",
                 esp_err_to_name(res));
        i2s_handle = NULL;
        return;
    }

    if (i2s_handle == NULL) {
        ESP_LOGE(TAG, "BSP returned a NULL audio I2S handle");
        return;
    }

    audio_volume_percentage = 50;

    res = audio_set_output_volume((float)audio_volume_percentage);
    if (res != ESP_OK) {
        ESP_LOGE(TAG,
                 "Failed to set audio volume: %s",
                 esp_err_to_name(res));
        return;
    }

    res = bsp_audio_set_amplifier(true);
    if (res != ESP_OK) {
        ESP_LOGE(TAG,
                 "Failed to enable audio amplifier: %s",
                 esp_err_to_name(res));
        return;
    }

    res = bsp_audio_set_amplifier_force(true);
    if (res != ESP_OK) {
        ESP_LOGE(TAG,
                 "Failed to force audio amplifier: %s",
                 esp_err_to_name(res));
        return;
    }

    ESP_LOGI(TAG, "Audio output configured: volume=50%% amplifier=on force=on");
}

/**
 * @brief Increase application-tracked audio volume by 1%, up to 100%.
 */
esp_err_t audio_volume_up(void)
{
    uint8_t next_volume = audio_volume_percentage;

    if (next_volume < 100) {
        next_volume = (uint8_t)(next_volume + 1);
        if (next_volume > 100) {
            next_volume = 100;
        }
    }

    if (next_volume == audio_volume_percentage) {
        ESP_LOGI(TAG, "Volume already at maximum: %u%%",
                 (unsigned int)audio_volume_percentage);
        return ESP_OK;
    }

    esp_err_t res = ESP_OK;

    if (!audio_muted) {
        res = audio_set_output_volume((float)next_volume);
        if (res != ESP_OK) {
            ESP_LOGE(TAG,
                     "Failed to increase volume to %u%%: %s",
                     (unsigned int)next_volume,
                     esp_err_to_name(res));
            return res;
        }
    }

    audio_volume_percentage = next_volume;
    ESP_LOGI(TAG, "Volume: %u%%",
             (unsigned int)audio_volume_percentage);
    return ESP_OK;
}

/**
 * @brief Decrease application-tracked audio volume by 1%, down to 0%.
 */
esp_err_t audio_volume_down(void)
{
    uint8_t next_volume = audio_volume_percentage;

    if (next_volume > 0) {
        next_volume = (uint8_t)(next_volume - 1);
    } else {
        next_volume = 0;
    }

    if (next_volume == audio_volume_percentage) {
        ESP_LOGI(TAG, "Volume already at minimum: %u%%",
                 (unsigned int)audio_volume_percentage);
        return ESP_OK;
    }

    esp_err_t res = ESP_OK;

    if (!audio_muted) {
        res = audio_set_output_volume((float)next_volume);
        if (res != ESP_OK) {
            ESP_LOGE(TAG,
                     "Failed to decrease volume to %u%%: %s",
                     (unsigned int)next_volume,
                     esp_err_to_name(res));
            return res;
        }
    }

    audio_volume_percentage = next_volume;
    ESP_LOGI(TAG, "Volume: %u%%",
             (unsigned int)audio_volume_percentage);
    return ESP_OK;
}

/**
 * @brief Return the TanRadio-owned current volume percentage.
 */
uint8_t audio_get_volume(void)
{
    return audio_volume_percentage;
}

/**
 * @brief Mute the audio codec without changing the configured volume.
 */
esp_err_t audio_mute(void)
{
    esp_err_t res = audio_set_output_volume(0.0f);

    if (res != ESP_OK) {
        ESP_LOGE(TAG,
                 "Failed to mute audio: %s",
                 esp_err_to_name(res));
        return res;
    }

    audio_muted = true;

    ESP_LOGI(TAG, "Audio muted");
    return ESP_OK;
}

/**
 * @brief Restore the configured volume after a temporary mute.
 */
esp_err_t audio_unmute(void)
{
    esp_err_t res = audio_set_output_volume(
        (float)audio_volume_percentage);

    if (res != ESP_OK) {
        ESP_LOGE(TAG,
                 "Failed to unmute audio: %s",
                 esp_err_to_name(res));
        return res;
    }

    audio_muted = false;

    ESP_LOGI(TAG,
             "Audio unmuted: volume=%u%%",
             audio_volume_percentage);

    return ESP_OK;
}

static esp_err_t audio_write_pcm_locked(const void *data, size_t size)
{
    if (i2s_handle == NULL) {
        ESP_LOGE(TAG, "Audio I2S handle is not initialized");
        return ESP_ERR_INVALID_STATE;
    }

    if (data == NULL || size == 0) {
        return ESP_ERR_INVALID_ARG;
    }

    size_t bytes_written = 0;

    esp_err_t res = i2s_channel_write(
        i2s_handle,
        data,
        size,
        &bytes_written,
        1000);

    if (res != ESP_OK) {
        ESP_LOGE(TAG,
                 "Failed to write PCM to I2S: %s",
                 esp_err_to_name(res));
        return res;
    }

    if (bytes_written != size) {
        ESP_LOGW(TAG,
                 "Partial PCM write: %zu of %zu bytes",
                 bytes_written,
                 size);
    }

    return ESP_OK;
}

esp_err_t audio_write_pcm(const void *data, size_t size)
{
    if (audio_write_mutex == NULL || atomic_load(&audio_shutdown_started)) {
        return ESP_ERR_INVALID_STATE;
    }
    xSemaphoreTake(audio_write_mutex, portMAX_DELAY);
    esp_err_t res = atomic_load(&audio_shutdown_started)
                        ? ESP_ERR_INVALID_STATE
                        : audio_write_pcm_locked(data, size);
    xSemaphoreGive(audio_write_mutex);
    return res;
}

static void audio_shutdown_check(esp_err_t res, const char *operation)
{
    if (res != ESP_OK) {
        ESP_LOGW(TAG, "Shutdown %s failed: %s", operation, esp_err_to_name(res));
    }
}

void audio_shutdown(void)
{
    /* Close admission before waiting for an in-flight write. Otherwise the
     * higher-priority PCM task could continually reacquire the write lock. */
    atomic_store(&audio_shutdown_started, true);
    if (audio_control_mutex != NULL) {
        xSemaphoreTake(audio_control_mutex, portMAX_DELAY);
    }
    audio_muted = true;

    /* Attempt every safety step even if a preceding hardware call fails.
     * The amplifier is coprocessor-owned and survives the CPU restart. */
    audio_shutdown_check(bsp_audio_set_volume(0.0f), "codec mute");
    audio_shutdown_check(bsp_audio_set_amplifier(false), "amplifier disable");
    audio_shutdown_check(bsp_audio_set_amplifier_force(false), "amplifier force release");

    if (audio_write_mutex != NULL) {
        xSemaphoreTake(audio_write_mutex, portMAX_DELAY);
    }
    if (i2s_handle != NULL) {
        i2s_chan_info_t info = {0};
        esp_err_t res = i2s_channel_get_info(i2s_handle, &info);
        audio_shutdown_check(res, "I2S information");
        if (res == ESP_OK) {
            static const uint8_t silence[1024] = {0};
            /* Two full DMA rings overwrite stale PCM and clock silence out.
             * No playback writer can enter while we hold the write mutex. */
            size_t remaining = 2 * info.total_dma_buf_size;
            while (remaining > 0) {
                size_t size = remaining < sizeof(silence) ? remaining : sizeof(silence);
                size_t written = 0;
                res = i2s_channel_write(i2s_handle, silence, size, &written, 100);
                if (res != ESP_OK || written != size) {
                    audio_shutdown_check(res != ESP_OK ? res : ESP_ERR_TIMEOUT,
                                         "silence flush");
                    break;
                }
                remaining -= written;
            }
        }
        esp_err_t disable_res = i2s_channel_disable(i2s_handle);
        audio_shutdown_check(disable_res, "I2S disable");
        if (disable_res == ESP_OK) {
            /* The BSP owns the channel; do not delete it. */
            i2s_handle = NULL;
        }
    }
    if (audio_write_mutex != NULL) {
        xSemaphoreGive(audio_write_mutex);
    }
    if (audio_control_mutex != NULL) {
        xSemaphoreGive(audio_control_mutex);
    }
}
