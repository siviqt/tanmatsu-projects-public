# TanRadio production changelog

## Country search and source privacy — 2026-10-20

- Add country search: Tab switches name/country mode, with country names and
  case-insensitive two-letter codes. Switching cancels pending results.
- Privacy audit of distributable source and firmware found no personal
  development data or credentials requiring removal. Retain public upstream
  attribution and certificate contacts. Gate source export on private-path and
  credential checks; refresh the prepared source snapshot and release.
- Build, ten regression checks and privacy checks pass. Country search awaits
  device validation.

## Previously device-validated production — 2026-10-20

- Midnight UI with readable Saira fonts, navy/slate panels and cyan selection.
- Two distinct F1 presses confirm exit; Esc/F2 cancels. The exit splash returns
  to the launcher after audio cleanup and omits “See you next time”.
- Responsive startup: UI/input open before background transport and SD setup.
  Reset the radio on each launch to discard stale SDIO state and prevent the
  oversized DMA allocation seen during warm application transitions.
- Start at 50% volume and adjust in 1% steps. Preserve responsive controls and
  safe, serialized audio shutdown.
- Search Radio Browser by station name, preview results, save stations to SD,
  and remove saved stations through confirmation. Keep active playback as a
  Preview when its saved row is removed. Preserve catalogs through failures
  and interrupted saves.
- Use verified HTTPS, mirror discovery, cancellation, bounded responses and
  one automatic retry for a connection failure when only one mirror is found.
  Intermittent remote directory TLS failures can still need a manual retry.
- Present complete native framebuffers, wait for scanout retirement before
  reuse, and retry failed updates without overwriting pending pages. Keep
  RGB565 and a ten-frame-per-second redraw limit. Use a 256 KiB L2 cache with
  128-byte lines following Espressif's DSI bandwidth guidance.
- Device validation: 15 successful station starts, responsive playback, no
  observed blue flash and correct exit text. No display/allocation/crash errors
  appeared in the final capture. Rare behavior beyond this test is unproven;
  the precise hardware cause has not been established.
- All nine regression checks and the ESP32-P4 production build pass.

The previously device-validated application had CRC32 `c082cc59`. The current
packaged application includes the country-search update; use its SHA-256
sidecar in `releases/` to verify it. Rebuilding may change image metadata and
checksums. No temporary white-fill diagnostic is included.

## Project maintenance

- Keep current production source, local component patches and licenses,
  configuration, assets, documentation, regression checks and one release image.
- Remove build/download/Python caches, an unused logo source image and upstream
  component-publishing automation. Preserve the existing repository history.
- Simplify build helpers, correct BadgeLink installation to the `tanradio` slug,
  and add `make test` and `make source-export` for a clean sharing snapshot.
