# TanRadio 0.7.1, revision 8

`TanRadio.bin` is the production Tanmatsu ESP32-P4 AppFS application built with
ESP-IDF 6.0.2, firmware version `0.7.1-r8`. It promotes the BSP 1.6.2, LCD
abstraction 1.1.0, ES8156 0.1.0 and LCD HAL integration from the test build.
Tap Hyper (between left Ctrl and Alt) to view About and its build information.

The owner reported all requested device checks passed on the preceding
0.7.0 revision 7 test image: About, playback/volume/output switching, display,
SD persistence and exit/relaunch. This production image is rebuilt with the
new version/revision and normal welcome subtitle. The automated production
suite contains 15 regression scripts, including SD/VCOM/DSI integration checks.

Verify the current binary from this directory:

```sh
sha256sum -c TanRadio.bin.sha256
```

From the project root, `make release` builds, checks and refreshes this image
and its checksum. `make package` also prepares the Tanmatsu repository package
and a separate personal Git source snapshot under `dist/TanRadio-0.7.1-r8/`.
Both carry the matching metadata, icons and license. Use AppFS revision **8**
for a manual BadgeLink upload; `make install` reads it from `metadata.json`.

This binary is an AppFS application image. Install it through the launcher or
BadgeLink. Historical test/rollback payloads retained in the working checkout
are excluded from the current source export and repository package.
