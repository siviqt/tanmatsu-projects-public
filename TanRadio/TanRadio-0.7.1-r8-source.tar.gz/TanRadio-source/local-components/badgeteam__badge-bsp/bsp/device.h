#pragma once

#include <stdbool.h>
#include <stdint.h>
#include "display.h"
#include "esp_err.h"

typedef struct {
    bsp_display_configuration_t display;
} bsp_configuration_t;

/// @brief Initialize the hardware managed by the BSP
/// @details Initialize the hardware and related drivers managed by the BSP
/// @return ESP-IDF error code
///          - ESP_OK if BSP initialized correctly
///          - ESP_FAIL if the BSP could not initialize
esp_err_t bsp_device_initialize(const bsp_configuration_t* configuration);

/// @brief Get the name of the device as a string
/// @details Returns the name as a null terminated string
/// @param[out] output Pointer to buffer to which the name string gets copied
/// @param[in] buffer_length Length of the output buffer
/// @return ESP-IDF error code
///          - ESP_OK if the output string fits in the buffer
///          - ESP_ERR_INVALID_ARG if the output pointer is NULL
esp_err_t bsp_device_get_name(char* output, uint8_t buffer_length);

/// @brief Get the name of the manufacturer as a string
/// @details Returns the name as a null terminated string
/// @param[out] output Pointer to buffer to which the name string gets copied
/// @param[in] buffer_length Length of the output buffer
/// @return ESP-IDF error code
///          - ESP_OK if the output string fits in the buffer
///          - ESP_ERR_INVALID_ARG if the output pointer is NULL
esp_err_t bsp_device_get_manufacturer(char* output, uint8_t buffer_length);

/// @brief Initialized without coprocessor status flag
/// @return Boolean, true when initialized without coprocessor available
bool bsp_device_get_initialized_without_coprocessor(void);

/// @brief Restarts the device, returning to the launcher
void bsp_device_restart_to_launcher(void);