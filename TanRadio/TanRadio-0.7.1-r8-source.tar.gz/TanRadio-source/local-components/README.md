# Production components

These are the components from the 0.7.0 revision 7 BSP test build, promoted
after the owner reported all requested hardware checks passed. Production
0.7.1 revision 8 retains their implementation unchanged.

`main/idf_component.yml` overrides the registry BSP, ES8156 and LCD abstraction
with these directories. Root CMake selects the local LCD HAL through
`EXTRA_COMPONENT_DIRS`; the installed ESP-IDF is unchanged.

| Component | Upstream base | Commit |
| --- | --- | --- |
| badge-bsp | 1.6.2 | `72d360a554ed6944e94faa9e804ee7e8f42777b9` |
| mipi_dsi_abstraction | 1.1.0 | `47b83bd968aa907915d766b85e71563d146104bc` |
| ES8156 | 0.1.0 | `97fc872701c5f548cf94c9c4896505aa752c0260` |
| ESP-IDF LCD HAL | 6.0.2 | `7101770dc6db2667b3c477cc31365dd1acd6db4e` |

Official component archive SHA-256 values used for the integration:

- BSP: `b4a86aa7d251341571ab9c743036bce5e6fade186e744683fbc3666ea931101b`.
- LCD abstraction: `4a639d3008d5dcccc185464c36f8625887ce09ad242b0db7a433249e3a1cbb4f`.

## TanRadio changes

- Audio: shared I2C locking, finite/clamped volume, upstream 0.70 gain scaling
  and matched left-justified 16-bit stereo I2S. The maximum codec register is
  0xB3 (approximately -6 dB). The ES8156 C/header sources match upstream 0.1.0.
  The app owns independent saved speaker/headphone volumes and safe shutdown.
- Display: two native framebuffers, frame-boundary switching, two-refresh page
  retirement and timeout ownership. Retain upstream VCOM APIs and saved
  `system/lcd_vcom` restoration; declare `nvs_flash` and propagate panel errors.
- Input: upstream right-Shift reporting/common hooks plus corrected dormant
  repeat bookkeeping. The app remains the only active repeat engine.
- Storage: the app delegates to BSP storage, defers mounting until Space,
  allows four open files and never auto-formats. The BSP owns power and the
  shared SDMMC/ESP-Hosted cleanup workaround.
- LCD HAL: stock ESP-IDF 6.0.2 lacks the timeout helper used by the released
  LCD abstraction. The local copy bounds command/BTA/FIFO polling with one
  100,000-microsecond budget, clears the receive buffer and exposes that helper.
  Reads must be serialized; the app's panel OTP read occurs during startup.

`patches/badge-bsp-1.6.2.patch` and `patches/esp-hal-lcd-6.0.2.patch` record the
changes against the upstream sources. Keep all local components together and
retain their licenses/manifests. BSP/LCD/ES8156 are MIT; the LCD HAL is Apache-2.0.
Do not edit generated component copies in `managed_components/`.
