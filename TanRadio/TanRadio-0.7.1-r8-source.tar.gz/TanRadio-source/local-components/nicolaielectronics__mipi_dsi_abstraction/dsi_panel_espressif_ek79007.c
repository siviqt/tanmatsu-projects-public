/*
 * SPDX-FileCopyrightText: 2024 Nicolai Electronics
 *
 * SPDX-License-Identifier: MIT
 */

#include "dsi_panel_espressif_ek79007.h"
#include <stdio.h>
#include <string.h>
#include "driver/gpio.h"
#include "esp_err.h"
#include "esp_lcd_ek79007.h"
#include "esp_lcd_mipi_dsi.h"
#include "esp_lcd_panel_ops.h"
#include "esp_ldo_regulator.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "freertos/FreeRTOS.h"
#include "freertos/semphr.h"
#include "freertos/task.h"
#include "sdkconfig.h"

static const char* TAG = "EK79007 panel";

// FPS = 48000000/(10+120+120+1024)/(1+20+10+600) = 60Hz
#define PANEL_MIPI_DSI_DPI_CLK_MHZ       48
#define PANEL_MIPI_DSI_LCD_H_RES         1024
#define PANEL_MIPI_DSI_LCD_V_RES         600
#define PANEL_MIPI_DSI_LCD_HSYNC         10
#define PANEL_MIPI_DSI_LCD_HBP           120
#define PANEL_MIPI_DSI_LCD_HFP           120
#define PANEL_MIPI_DSI_LCD_VSYNC         1
#define PANEL_MIPI_DSI_LCD_VBP           20
#define PANEL_MIPI_DSI_LCD_VFP           10
#define PANEL_MIPI_DSI_LANE_NUM          2     // 2 data lanes
#define PANEL_MIPI_DSI_LANE_BITRATE_MBPS 1000  // 1Gbps

static esp_lcd_panel_handle_t mipi_dpi_panel = NULL;

esp_lcd_panel_handle_t ek79007_get_panel(void) {
    return mipi_dpi_panel;
}

esp_err_t ek79007_get_parameters(size_t* h_res, size_t* v_res, lcd_color_format_t* color_fmt) {
    if (h_res) {
        *h_res = PANEL_MIPI_DSI_LCD_H_RES;
    }
    if (v_res) {
        *v_res = PANEL_MIPI_DSI_LCD_V_RES;
    }
    if (color_fmt) {
        *color_fmt = LCD_COLOR_FMT_RGB888;
    }
    return ESP_OK;
}

esp_err_t ek79007_initialize(const ek79007_configuration_t* config) {
    // create MIPI DSI bus first, it will initialize the DSI PHY as well
    esp_lcd_dsi_bus_handle_t mipi_dsi_bus;
    esp_lcd_dsi_bus_config_t bus_config = {
        .bus_id = 0,
        .num_data_lanes = PANEL_MIPI_DSI_LANE_NUM,
        .lane_bit_rate_mbps = PANEL_MIPI_DSI_LANE_BITRATE_MBPS,
    };
    ESP_ERROR_CHECK(esp_lcd_new_dsi_bus(&bus_config, &mipi_dsi_bus));

    ESP_LOGI(TAG, "Install MIPI DSI LCD control IO");
    esp_lcd_panel_io_handle_t mipi_dbi_io;
    // we use DBI interface to send LCD commands and parameters
    esp_lcd_dbi_io_config_t dbi_config = {
        .virtual_channel = 0,
        .lcd_cmd_bits = 8,    // according to the LCD spec
        .lcd_param_bits = 8,  // according to the LCD spec
    };
    ESP_ERROR_CHECK(esp_lcd_new_panel_io_dbi(mipi_dsi_bus, &dbi_config, &mipi_dbi_io));

    ESP_LOGI(TAG, "Install MIPI DSI LCD data panel");
    esp_lcd_dpi_panel_config_t dpi_config = {
        .virtual_channel = 0,
        .dpi_clk_src = MIPI_DSI_DPI_CLK_SRC_DEFAULT,
        .dpi_clock_freq_mhz = PANEL_MIPI_DSI_DPI_CLK_MHZ,
        .in_color_format = LCD_COLOR_FMT_RGB888,
        .num_fbs = config->num_fbs,
        .video_timing =
            {
                .h_size = PANEL_MIPI_DSI_LCD_H_RES,
                .v_size = PANEL_MIPI_DSI_LCD_V_RES,
                .hsync_back_porch = PANEL_MIPI_DSI_LCD_HBP,
                .hsync_pulse_width = PANEL_MIPI_DSI_LCD_HSYNC,
                .hsync_front_porch = PANEL_MIPI_DSI_LCD_HFP,
                .vsync_back_porch = PANEL_MIPI_DSI_LCD_VBP,
                .vsync_pulse_width = PANEL_MIPI_DSI_LCD_VSYNC,
                .vsync_front_porch = PANEL_MIPI_DSI_LCD_VFP,
            },
    };

    ek79007_vendor_config_t vendor_config = {
        .mipi_config =
            {
                .dsi_bus = mipi_dsi_bus,
                .dpi_config = &dpi_config,
            },
    };
    esp_lcd_panel_dev_config_t lcd_dev_config = {
        .reset_gpio_num = config->reset_pin,
        .rgb_ele_order = LCD_RGB_ELEMENT_ORDER_RGB,
        .bits_per_pixel = 24,
        .vendor_config = &vendor_config,
    };
    ESP_ERROR_CHECK(esp_lcd_new_panel_ek79007(mipi_dbi_io, &lcd_dev_config, &mipi_dpi_panel));

    ESP_ERROR_CHECK(esp_lcd_dpi_panel_enable_dma2d(mipi_dpi_panel));

    ESP_ERROR_CHECK(esp_lcd_panel_reset(mipi_dpi_panel));
    ESP_ERROR_CHECK(esp_lcd_panel_init(mipi_dpi_panel));

    /*ESP_LOGI(TAG, "Register DPI panel event callback for flush ready notification");
    esp_lcd_dpi_panel_event_callbacks_t cbs = {
        //.on_color_trans_done = ...,
        //.on_refresh_done = ...,
    };
    ESP_ERROR_CHECK(esp_lcd_dpi_panel_register_event_callbacks(mipi_dpi_panel, &cbs, display));*/

    return ESP_OK;
}
